const socket = io();
const $ = id => document.getElementById(id);
let currentRoom = null;
let myMark = null;
let latestState = null;
let toastTimer;

function nameValue() {
  const input = $("playerName");
  const name = input.value.trim();
  if (!name) { input.focus(); showToast("اكتب اسمك الأول."); return null; }
  return name.slice(0, 18);
}
function showToast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function showGame(code) {
  currentRoom = code;
  $("activeCode").textContent = code;
  $("lobby").classList.add("hidden");
  $("game").classList.remove("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
}
function showLobby() {
  $("game").classList.add("hidden");
  $("lobby").classList.remove("hidden");
  currentRoom = null;
  myMark = null;
  latestState = null;
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

socket.on("connect", () => {
  $("connection").textContent = "متصل بالسيرفر";
});
socket.on("disconnect", () => {
  $("connection").textContent = "الاتصال انقطع";
  showToast("انقطع الاتصال. بنحاول نرجعه...");
});
socket.on("connect_error", () => $("connection").textContent = "تعذر الاتصال");

$("createPrivate").addEventListener("click", () => {
  const name = nameValue(); if (name) socket.emit("create-room", {name});
});
$("createPublic").addEventListener("click", () => {
  const name = nameValue(); if (name) socket.emit("create-public-room", {name});
});
$("quickMatch").addEventListener("click", () => {
  const name = nameValue(); if (name) socket.emit("quick-match", {name});
});
$("joinRoom").addEventListener("click", () => {
  const name = nameValue(); if (!name) return;
  const code = $("roomCode").value.trim().toUpperCase();
  if (!code) return showToast("اكتب كود الغرفة.");
  socket.emit("join-room", {name, code});
});
$("roomCode").addEventListener("keydown", e => { if (e.key === "Enter") $("joinRoom").click(); });
$("refreshRooms").addEventListener("click", () => showToast("قائمة الغرف بتتحدث تلقائيًا."));
$("leaveGame").addEventListener("click", () => { socket.emit("leave-room"); showLobby(); });
$("backLobby").addEventListener("click", () => { socket.emit("leave-room"); showLobby(); });
$("copyCode").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(currentRoom || ""); showToast("تم نسخ كود الغرفة."); }
  catch { showToast("كود الغرفة: " + currentRoom); }
});
$("rematch").addEventListener("click", () => socket.emit("rematch"));
document.querySelectorAll(".cell").forEach(cell => {
  cell.addEventListener("click", () => {
    if (!latestState || latestState.status !== "playing") return;
    socket.emit("play", {index:Number(cell.dataset.index)});
  });
});

socket.on("room-created", ({code}) => {
  showGame(code);
  myMark = "X";
  showToast("تم إنشاء الغرفة. ابعت الكود لصاحبك!");
});
socket.on("joined-room", ({code}) => {
  showGame(code);
  showToast("دخلت الغرفة بنجاح.");
});
socket.on("left-room", () => showLobby());
socket.on("notice", showToast);

socket.on("game-state", state => {
  latestState = state;
  if (state.code !== currentRoom) showGame(state.code);
  const players = state.players || [];
  myMark = players.find(p => p.name === $("playerName").value.trim())?.mark || myMark;
  $("activeCode").textContent = state.code;
  $("gameMessage").textContent = state.message || "";
  const px = $("playerX"), po = $("playerO");
  const xPlayer = players.find(p => p.mark === "X");
  const oPlayer = players.find(p => p.mark === "O");
  px.querySelector("strong").textContent = xPlayer ? xPlayer.name : "بانتظار لاعب";
  po.querySelector("strong").textContent = oPlayer ? oPlayer.name : "بانتظار لاعب";
  px.classList.toggle("active", state.status === "playing" && state.turn === "X");
  po.classList.toggle("active", state.status === "playing" && state.turn === "O");
  document.querySelectorAll(".cell").forEach((cell, i) => {
    const mark = state.board[i];
    cell.textContent = mark || "";
    cell.classList.toggle("x", mark === "X");
    cell.classList.toggle("o", mark === "O");
    cell.disabled = !!mark || state.status !== "playing" || state.turn !== myMark;
  });
  $("rematch").disabled = state.status !== "finished";
});

socket.on("public-rooms", rooms => {
  const list = $("roomsList");
  if (!rooms.length) {
    list.innerHTML = '<div class="empty">مفيش غرف متاحة حاليًا. أنشئ غرفة عامة وابدأ التحدي!</div>';
    return;
  }
  list.innerHTML = rooms.map(room => `<div class="room-item"><div class="room-info"><strong>غرفة عامة</strong><small>${room.players}/2 لاعبين • ${escapeHtml(room.status)}</small></div><span class="room-code">${escapeHtml(room.code)}</span><button data-join="${escapeHtml(room.code)}">انضم</button></div>`).join("");
  list.querySelectorAll("[data-join]").forEach(btn => btn.addEventListener("click", () => {
    const name = nameValue(); if (name) socket.emit("join-public-room", {name, code:btn.dataset.join});
  }));
});
socket.on("leaderboard", scores => {
  const list = $("leaderboard");
  if (!scores.length) { list.innerHTML = '<div class="empty">لا توجد نتائج حتى الآن</div>'; return; }
  list.innerHTML = scores.map((s,i) => `<div class="rank-item"><span class="rank-number">${i+1}</span><div class="rank-info"><strong>${escapeHtml(s.name)}</strong><small>${s.losses} خسارة • ${s.draws} تعادل</small></div><span class="rank-wins">🏆 ${s.wins}</span></div>`).join("");
});
