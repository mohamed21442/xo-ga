const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

const rooms = new Map();
const scores = new Map(); // In-memory leaderboard; resets when server restarts.
const waiting = new Set();

function cleanName(value) {
  return String(value || "لاعب").trim().replace(/[<>]/g, "").slice(0, 18) || "لاعب";
}
function makeCode() {
  let code;
  do { code = crypto.randomBytes(3).toString("hex").toUpperCase(); }
  while (rooms.has(code));
  return code;
}
function player(socketId, name, mark) {
  return { id: socketId, name, mark };
}
function roomSummary(room) {
  return {
    code: room.code,
    type: room.type,
    players: room.players.length,
    status: room.players.length < 2 ? "بانتظار لاعب" : room.status === "playing" ? "جارية" : "جاهزة"
  };
}
function publicRooms() {
  return [...rooms.values()]
    .filter(r => r.type === "public" && r.players.length < 2)
    .map(roomSummary);
}
function emitPublicRooms() { io.emit("public-rooms", publicRooms()); }
function sendState(room) {
  io.to(room.code).emit("game-state", {
    code: room.code,
    type: room.type,
    board: room.board,
    players: room.players.map(p => ({ name: p.name, mark: p.mark, connected: true })),
    turn: room.turn,
    status: room.status,
    message: room.message
  });
}
function getRoomForSocket(socket) {
  if (!socket.data.roomCode) return null;
  return rooms.get(socket.data.roomCode) || null;
}
function getScore(name) {
  if (!scores.has(name)) scores.set(name, { name, wins: 0, losses: 0, draws: 0 });
  return scores.get(name);
}
function clearRoom(room) {
  for (const p of room.players) {
    const s = io.sockets.sockets.get(p.id);
    if (s) { s.leave(room.code); s.data.roomCode = null; }
  }
  rooms.delete(room.code);
  emitPublicRooms();
}
function createRoom(socket, name, type) {
  const code = makeCode();
  const room = {
    code, type, players: [player(socket.id, name, "X")],
    board: Array(9).fill(""), turn: "X", status: "waiting",
    message: "بانتظار اللاعب الثاني..."
  };
  rooms.set(code, room);
  socket.join(code);
  socket.data.roomCode = code;
  socket.emit("room-created", { code, type });
  sendState(room);
  emitPublicRooms();
  return room;
}
function startIfReady(room) {
  if (room.players.length === 2) {
    room.status = "playing";
    room.board = Array(9).fill("");
    room.turn = "X";
    room.message = `دور ${room.players[0].name} (X)`;
    sendState(room);
  }
}
function winner(board) {
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for (const [a,b,c] of lines) if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  return board.every(Boolean) ? "draw" : null;
}

io.on("connection", socket => {
  socket.emit("public-rooms", publicRooms());
  socket.emit("leaderboard", [...scores.values()].sort((a,b) => b.wins-a.wins).slice(0,10));

  socket.on("create-room", data => {
    if (getRoomForSocket(socket)) return socket.emit("notice", "اخرج من الغرفة الحالية أولًا.");
    const name = cleanName(data && data.name);
    createRoom(socket, name, "private");
  });

  socket.on("create-public-room", data => {
    if (getRoomForSocket(socket)) return socket.emit("notice", "اخرج من الغرفة الحالية أولًا.");
    createRoom(socket, cleanName(data && data.name), "public");
  });

  socket.on("join-room", data => {
    if (getRoomForSocket(socket)) return socket.emit("notice", "اخرج من الغرفة الحالية أولًا.");
    const code = String(data && data.code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return socket.emit("notice", "الغرفة غير موجودة. تأكد من الكود.");
    if (room.players.length >= 2) return socket.emit("notice", "الغرفة مكتملة.");
    const name = cleanName(data && data.name);
    room.players.push(player(socket.id, name, "O"));
    socket.join(code);
    socket.data.roomCode = code;
    socket.emit("joined-room", { code, type: room.type });
    startIfReady(room);
    emitPublicRooms();
  });

  socket.on("quick-match", data => {
    if (getRoomForSocket(socket)) return socket.emit("notice", "اخرج من الغرفة الحالية أولًا.");
    const name = cleanName(data && data.name);
    const waitingRoom = [...rooms.values()].find(r => r.type === "public" && r.players.length === 1 && r.status === "waiting" && r.players[0].id !== socket.id);
    if (waitingRoom) {
      waitingRoom.players.push(player(socket.id, name, "O"));
      socket.join(waitingRoom.code);
      socket.data.roomCode = waitingRoom.code;
      socket.emit("joined-room", { code: waitingRoom.code, type: "public" });
      startIfReady(waitingRoom);
      emitPublicRooms();
    } else {
      createRoom(socket, name, "public");
      socket.emit("notice", "أنشأنا غرفة عامة لك. نبحث عن لاعب...");
    }
  });

  socket.on("join-public-room", data => {
    if (getRoomForSocket(socket)) return socket.emit("notice", "اخرج من الغرفة الحالية أولًا.");
    const code = String(data && data.code || "");
    const room = rooms.get(code);
    if (!room || room.type !== "public") return socket.emit("notice", "الغرفة لم تعد متاحة.");
    if (room.players.length >= 2) return socket.emit("notice", "الغرفة مكتملة.");
    room.players.push(player(socket.id, cleanName(data && data.name), "O"));
    socket.join(code);
    socket.data.roomCode = code;
    socket.emit("joined-room", { code, type: "public" });
    startIfReady(room);
    emitPublicRooms();
  });

  socket.on("play", data => {
    const room = getRoomForSocket(socket);
    if (!room || room.status !== "playing") return;
    const idx = Number(data && data.index);
    const current = room.players.find(p => p.id === socket.id);
    if (!current || current.mark !== room.turn || !Number.isInteger(idx) || idx < 0 || idx > 8 || room.board[idx]) return;
    room.board[idx] = current.mark;
    const result = winner(room.board);
    if (result) {
      room.status = "finished";
      if (result === "draw") {
        room.message = "تعادل! مباراة قوية.";
        room.players.forEach(p => getScore(p.name).draws++);
      } else {
        const winPlayer = room.players.find(p => p.mark === result);
        const losePlayer = room.players.find(p => p.mark !== result);
        room.message = `🎉 ${winPlayer.name} فاز!`;
        getScore(winPlayer.name).wins++;
        getScore(losePlayer.name).losses++;
      }
      sendState(room);
      io.emit("leaderboard", [...scores.values()].sort((a,b) => b.wins-a.wins || a.losses-b.losses).slice(0,10));
    } else {
      room.turn = room.turn === "X" ? "O" : "X";
      const next = room.players.find(p => p.mark === room.turn);
      room.message = `دور ${next ? next.name : room.turn} (${room.turn})`;
      sendState(room);
    }
  });

  socket.on("rematch", () => {
    const room = getRoomForSocket(socket);
    if (!room || room.players.length !== 2 || room.status !== "finished") return;
    room.board = Array(9).fill("");
    room.turn = "X";
    room.status = "playing";
    room.message = `مباراة جديدة! دور ${room.players.find(p => p.mark === "X").name} (X)`;
    sendState(room);
  });

  socket.on("leave-room", () => {
    const room = getRoomForSocket(socket);
    if (room) {
      socket.leave(room.code);
      socket.data.roomCode = null;
      room.players = room.players.filter(p => p.id !== socket.id);
      if (room.players.length === 0) rooms.delete(room.code);
      else {
        room.status = "waiting";
        room.board = Array(9).fill("");
        room.turn = "X";
        room.players[0].mark = "X";
        room.message = "غادر اللاعب الآخر. بانتظار لاعب جديد...";
        sendState(room);
      }
      emitPublicRooms();
    }
    socket.emit("left-room");
  });

  socket.on("disconnect", () => {
    waiting.delete(socket.id);
    const room = getRoomForSocket(socket);
    if (room) {
      room.players = room.players.filter(p => p.id !== socket.id);
      if (room.players.length === 0) rooms.delete(room.code);
      else {
        room.status = "waiting";
        room.board = Array(9).fill("");
        room.turn = "X";
        room.players[0].mark = "X";
        room.message = "انقطع اتصال اللاعب الآخر. بانتظار لاعب جديد...";
        sendState(room);
      }
      emitPublicRooms();
    }
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`XO Online running on port ${PORT}`));
